import Link from "next/link";

export function Topbar() {
  return (
    <div className="topbar">
      <nav className="topbarInner" aria-label="Primary">
        <Link href="/">Home</Link>
        <Link href="/research">Research</Link>
        <Link href="/talks">Talks</Link>
        <Link href="/teaching">Teaching</Link>
        <Link href="/ai4bio">AI4Bio Learning Hub</Link>
      </nav>
    </div>
  );
}
