import Image from "next/image";
import { siteData } from "@/data/siteData";
import { IconGithub, IconLinkedIn, IconLink, IconMail } from "@/components/Icons";

export function Sidebar() {
  const { contact, assets } = siteData;
  const githubUrl = contact.githubHandle ? `https://github.com/${contact.githubHandle}` : "";
  const websiteUrl = contact.website ? (contact.website.startsWith("http") ? contact.website : `https://${contact.website}`) : "";

  return (
    <aside className="sidebar" aria-label="Sidebar">
      <div className="avatar" title="Replace with your headshot (public/avatar.jpg) if you want">
        <Image src={assets.avatar} alt="Aria Alisoltani avatar" width={190} height={190} priority />
      </div>

      <div className="sideLinks">
        <a href={`mailto:${contact.email}`}>
          <IconMail className="icon" />
          Email
        </a>

        {contact.linkedin ? (
          <a href={contact.linkedin} target="_blank" rel="noopener">
            <IconLinkedIn className="icon" />
            LinkedIn
          </a>
        ) : (
          <span className="sideLinkDisabled" title="Add your LinkedIn URL in data/siteData.ts">
            <IconLinkedIn className="icon" />
            LinkedIn
          </span>
        )}

        {githubUrl ? (
          <a href={githubUrl} target="_blank" rel="noopener">
            <IconGithub className="icon" />
            GitHub
          </a>
        ) : null}

        {websiteUrl ? (
          <a href={websiteUrl} target="_blank" rel="noopener">
            <IconLink className="icon" />
            Website
          </a>
        ) : null}
      </div>
    </aside>
  );
}
