import React from "react";

export function IconMail(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" fill="none" {...props}>
      <path d="M4 7.5A2.5 2.5 0 0 1 6.5 5h11A2.5 2.5 0 0 1 20 7.5v9A2.5 2.5 0 0 1 17.5 19h-11A2.5 2.5 0 0 1 4 16.5v-9Z" stroke="currentColor" strokeWidth="1.8"/>
      <path d="m5.5 7 6.1 5.1a1 1 0 0 0 1.3 0L19.1 7" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/>
    </svg>
  );
}

export function IconLink(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" fill="none" {...props}>
      <path d="M10.5 13.5 13.5 10.5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/>
      <path d="M9 17a4 4 0 0 1 0-6l2-2a4 4 0 0 1 6 6l-2 2" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/>
    </svg>
  );
}

export function IconGithub(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" fill="none" {...props}>
      <path d="M12 2.7a9.5 9.5 0 0 0-3 18.5c.5.1.7-.2.7-.5v-1.7c-2.8.6-3.4-1.2-3.4-1.2-.5-1.1-1.2-1.4-1.2-1.4-1-.7.1-.7.1-.7 1.1.1 1.7 1.1 1.7 1.1 1 .1.8-1.4 2.9-2 .1-.8.4-1.4.8-1.7-2.2-.2-4.6-1.1-4.6-5.1 0-1.1.4-2 1.1-2.7-.1-.3-.5-1.4.1-2.9 0 0 .9-.3 2.9 1.1a10 10 0 0 1 5.2 0C16.1 4 17 4.3 17 4.3c.6 1.5.2 2.6.1 2.9.7.7 1.1 1.6 1.1 2.7 0 4-2.4 4.9-4.6 5.1.4.3.9 1.1.9 2.2v3.3c0 .3.2.6.7.5A9.5 9.5 0 0 0 12 2.7Z" stroke="currentColor" strokeWidth="1.2"/>
    </svg>
  );
}

export function IconLinkedIn(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" fill="none" {...props}>
      <path d="M6.5 9.5V18" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/>
      <path d="M6.5 6.5h.01" stroke="currentColor" strokeWidth="3" strokeLinecap="round"/>
      <path d="M10 18v-4.8c0-1.9 1.1-3.2 3-3.2s3 1.3 3 3.2V18" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/>
    </svg>
  );
}
