import React from "react";

export function Card({ children }: { children: React.ReactNode }) {
  return <div className="card">{children}</div>;
}

export function Section({ title, subtitle, children, id }: { title: string; subtitle?: string; children: React.ReactNode; id?: string }) {
  return (
    <section id={id} className="card section">
      <h2>{title}</h2>
      {subtitle ? <p className="sub">{subtitle}</p> : null}
      {children}
    </section>
  );
}

export function Callout({ tone, emoji, text }: { tone: "blue" | "orange"; emoji: string; text: string }) {
  return (
    <div className={`callout ${tone}`}>
      <p>
        <span className="emoji">{emoji}</span> {text}
      </p>
    </div>
  );
}

export function Item({ role, where, when, bullets }: { role: string; where?: string; when?: string; bullets?: string[] }) {
  return (
    <div className="item">
      <div className="itemTop">
        <div>
          <div className="role">{role}</div>
          {where ? <div className="where">{where}</div> : null}
        </div>
        {when ? <div className="when">{when}</div> : null}
      </div>
      {bullets?.length ? (
        <ul>
          {bullets.map((b, i) => (
            <li key={i}>{b}</li>
          ))}
        </ul>
      ) : null}
    </div>
  );
}
