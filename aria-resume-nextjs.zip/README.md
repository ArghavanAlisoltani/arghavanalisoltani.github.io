# Aria resume site (Next.js)

This is a clean resume landing page styled like your reference screenshot.

## Run locally
```bash
npm install
npm run dev
```
Then open http://localhost:3000

## Deploy
- **Vercel**: push to GitHub and import the repo.
- **Static export (GitHub Pages / any static host)**:
  1) In `next.config.mjs`, uncomment `output: "export"`.
  2) Run:
     ```bash
     npm run export
     ```
  3) Upload the generated `out/` folder.

## Update content
- Edit `data/siteData.ts` to change text, links, and sections.
- Replace `public/avatar-placeholder.svg` (or add `public/avatar.jpg` and set it in data).
- Replace `public/Aria_Alisoltani_CV.pdf` with your newest CV (keep the same filename).
