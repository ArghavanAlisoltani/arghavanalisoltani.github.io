import Link from "next/link";
import { Sidebar } from "@/components/Sidebar";
import { Section } from "@/components/Cards";
import { siteData } from "@/data/siteData";

export default function TalksPage() {
  const d = siteData;

  return (
    <div className="wrap">
      <div className="grid">
        <Sidebar />

        <main>
          <div className="card hero">
            <h1 className="name">Talks & Publications</h1>
            <div className="tagline">Metrics and placeholders (add your talk list when ready)</div>

            <div className="pillRow">
              <span className="pill">h-index: {d.pubs.hIndex}</span>
              <span className="pill">i10-index: {d.pubs.i10}</span>
              <span className="pill">Citations: {d.pubs.citations}</span>
            </div>

            <div className="btnRow" style={{ marginTop: 10 }}>
              <a className="btn primary" href={d.assets.resumePdf} download>
                ⬇️ Download Resume
              </a>
              <Link className="btn" href="/">
                Back to Home
              </Link>
            </div>
          </div>

          <Section title="Add your talk list" subtitle="A simple format you can paste in: title • venue • year • link">
            <div className="item">
              <div className="role">Example</div>
              <ul>
                <li>“Structure-aware interpretation of viral variants” • Seminar • 2025 • (link)</li>
                <li>“Meta-omics approaches to genital inflammation” • Conference • 2024 • (link)</li>
              </ul>
              <p className="sub" style={{ marginTop: 10 }}>
                Tip: If you share your Google Scholar / ORCID links, you can add them in <code>data/siteData.ts</code>
                and display them here.
              </p>
            </div>
          </Section>

          <footer className="footer">© {new Date().getFullYear()} Arghavan (Aria) Alisoltani</footer>
        </main>
      </div>
    </div>
  );
}
