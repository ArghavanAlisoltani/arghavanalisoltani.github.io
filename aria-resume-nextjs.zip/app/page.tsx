import Link from "next/link";
import { Sidebar } from "@/components/Sidebar";
import { Callout, Item, Section } from "@/components/Cards";
import { siteData } from "@/data/siteData";

export default function HomePage() {
  const d = siteData;

  return (
    <div className="wrap">
      <div className="grid">
        <Sidebar />

        <main>
          <div className="card hero">
            <h1 className="name">{d.name}</h1>
            <div className="tagline">{d.headline}</div>

            <div className="calloutStack">
              {d.callouts.map((c, idx) => (
                <Callout key={idx} tone={c.tone as any} emoji={c.emoji} text={c.text} />
              ))}
            </div>

            <div className="pillRow" aria-label="Highlights">
              {d.highlights.map((h, i) => (
                <span className="pill" key={i}>
                  {h}
                </span>
              ))}
            </div>

            <div className="bioRow">
              <div className="bioText">
                <b>Contact:</b> {d.contact.email} · {d.contact.phone} · {d.contact.location}
              </div>
              <div className="btnRow">
                <a className="btn primary" href={d.assets.resumePdf} download>
                  ⬇️ Download Resume (PDF)
                </a>
                <Link className="btn" href="/research">
                  Explore Research
                </Link>
              </div>
            </div>
          </div>

          <Section
            id="experience"
            title="Professional Experience"
            subtitle="Selected roles and responsibilities (edit in data/siteData.ts)."
          >
            <div className="list">
              {d.experience.slice(0, 3).map((x, i) => (
                <Item
                  key={i}
                  role={x.role}
                  where={`${x.org} • ${x.where}`}
                  when={x.when}
                  bullets={x.bullets}
                />
              ))}
            </div>

            <div className="btnRow" style={{ marginTop: 12 }}>
              <Link className="btn" href="/talks">
                Publications & Talks
              </Link>
              <Link className="btn" href="/teaching">
                Teaching
              </Link>
              <Link className="btn" href="/ai4bio">
                AI4Bio Hub
              </Link>
            </div>
          </Section>

          <Section title="Skills Snapshot" subtitle="A quick overview (full list in the CV).">
            <div className="twoCol">
              <div className="item">
                <div className="role">Bioinformatics & Data Science</div>
                <ul>
                  {d.skills.languages.slice(0, 4).map((s, i) => (
                    <li key={i}>{s}</li>
                  ))}
                  {d.skills.dataScience.slice(0, 4).map((s, i) => (
                    <li key={`ds-${i}`}>{s}</li>
                  ))}
                </ul>
              </div>

              <div className="item">
                <div className="role">Big Data & Omics</div>
                <ul>
                  {d.skills.bigData.map((s, i) => (
                    <li key={i}>{s}</li>
                  ))}
                  {d.skills.omics.slice(0, 5).map((s, i) => (
                    <li key={`o-${i}`}>{s}</li>
                  ))}
                </ul>
              </div>
            </div>
          </Section>

          <footer className="footer">© {new Date().getFullYear()} Arghavan (Aria) Alisoltani</footer>
        </main>
      </div>
    </div>
  );
}
