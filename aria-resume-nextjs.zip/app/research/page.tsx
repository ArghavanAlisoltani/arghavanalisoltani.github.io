import Link from "next/link";
import { Sidebar } from "@/components/Sidebar";
import { Item, Section } from "@/components/Cards";
import { siteData } from "@/data/siteData";

export default function ResearchPage() {
  const d = siteData;

  return (
    <div className="wrap">
      <div className="grid">
        <Sidebar />

        <main>
          <div className="card hero">
            <h1 className="name">Research</h1>
            <div className="tagline">ML-enabled tools • multi-omics • structure-guided interpretation</div>

            <div className="calloutStack">
              <div className="callout blue">
                <p>
                  <span className="emoji">🧠</span> I develop ML-powered webtools (ViralVar, MetaProt) and
                  visualization platforms (Coronavirus3D, FGTDB) to connect genomic variation with protein
                  structure, function, and phenotype.
                </p>
              </div>
              <div className="callout orange">
                <p>
                  <span className="emoji">🧬</span> I apply GWAS/marker discovery and multi-omics to study host–microbe
                  interactions, antimicrobial resistance, inflammation, and disease mechanisms.
                </p>
              </div>
            </div>

            <div className="btnRow" style={{ marginTop: 10 }}>
              <a className="btn primary" href={d.assets.resumePdf} download>
                ⬇️ Download Resume
              </a>
              <Link className="btn" href="/">
                Back to Home
              </Link>
            </div>
          </div>

          <Section title="Selected Experience" subtitle="Relevant positions from your CV.">
            <div className="list">
              {d.experience.map((x, i) => (
                <Item key={i} role={x.role} where={`${x.org} • ${x.where}`} when={x.when} bullets={x.bullets} />
              ))}
            </div>
          </Section>

          <Section
            title="Technical Focus"
            subtitle="Edit freely: these are meant as high-level “themes” mirroring your CV."
          >
            <div className="twoCol">
              <div className="item">
                <div className="role">Variant interpretation + structure</div>
                <ul>
                  <li>Structure-aware analyses (PyMOL, AlphaFold) to interpret protein mutations.</li>
                  <li>Mechanistic framing for viral evolution and host–pathogen interaction.</li>
                  <li>Interactive visualization for rapid exploration and communication.</li>
                </ul>
              </div>
              <div className="item">
                <div className="role">Multi-omics + scalable pipelines</div>
                <ul>
                  <li>WGS/variants, GWAS, pan-genome, RNA-seq, scRNA-seq.</li>
                  <li>Metagenomics/metaproteomics and systems biology (WGCNA, Cytoscape).</li>
                  <li>Reproducible workflows using Nextflow, HPC, and cloud storage (AWS S3, gcloud).</li>
                </ul>
              </div>
            </div>
          </Section>

          <footer className="footer">© {new Date().getFullYear()} Arghavan (Aria) Alisoltani</footer>
        </main>
      </div>
    </div>
  );
}
