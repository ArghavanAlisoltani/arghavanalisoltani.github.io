import Link from "next/link";
import { Sidebar } from "@/components/Sidebar";
import { Section } from "@/components/Cards";
import { siteData } from "@/data/siteData";

export default function TeachingPage() {
  const d = siteData;

  return (
    <div className="wrap">
      <div className="grid">
        <Sidebar />

        <main>
          <div className="card hero">
            <h1 className="name">Teaching</h1>
            <div className="tagline">Course ideas aligned with your strengths</div>

            <div className="btnRow" style={{ marginTop: 10 }}>
              <Link className="btn" href="/">
                Back to Home
              </Link>
              <Link className="btn" href="/ai4bio">
                AI4Bio Hub
              </Link>
            </div>
          </div>

          <Section title="Potential courses" subtitle="Edit/rename freely (data/siteData.ts).">
            <div className="item">
              <div className="role">Top course themes</div>
              <ul>
                {d.teachingIdeas.map((x, i) => (
                  <li key={i}>{x}</li>
                ))}
              </ul>
            </div>

            <div className="twoCol">
              <div className="item">
                <div className="role">Hands-on modules</div>
                <ul>
                  <li>Reproducible pipelines: conda, containers, Nextflow, HPC job arrays</li>
                  <li>Variant annotation: VCF → effects (synonymous/missense) → gene-level summaries</li>
                  <li>Model evaluation: CV, leakage checks, calibration, interpretability</li>
                </ul>
              </div>
              <div className="item">
                <div className="role">Deliverables for students</div>
                <ul>
                  <li>GitHub-ready projects with READMEs and tests</li>
                  <li>Notebook + report templates (figures, captions, methods)</li>
                  <li>Mini “web demo” (Shiny or simple Next.js dashboard)</li>
                </ul>
              </div>
            </div>
          </Section>

          <footer className="footer">© {new Date().getFullYear()} Arghavan (Aria) Alisoltani</footer>
        </main>
      </div>
    </div>
  );
}
