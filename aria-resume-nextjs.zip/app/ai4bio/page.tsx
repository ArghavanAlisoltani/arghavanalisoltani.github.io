import Link from "next/link";
import { Sidebar } from "@/components/Sidebar";
import { Section } from "@/components/Cards";
import { siteData } from "@/data/siteData";

export default function AI4BioPage() {
  const d = siteData;

  return (
    <div className="wrap">
      <div className="grid">
        <Sidebar />

        <main>
          <div className="card hero">
            <h1 className="name">AI4Bio Learning Hub</h1>
            <div className="tagline">Tutorials, reusable pipelines, and explainers</div>

            <div className="btnRow" style={{ marginTop: 10 }}>
              <Link className="btn" href="/">
                Back to Home
              </Link>
              <a className="btn primary" href={d.assets.resumePdf} download>
                ⬇️ Download Resume
              </a>
            </div>
          </div>

          <Section title="What you can host here" subtitle="Use this page as a simple “portal” for your content.">
            <div className="twoCol">
              <div className="item">
                <div className="role">Content ideas</div>
                <ul>
                  {d.ai4bioIdeas.map((x, i) => (
                    <li key={i}>{x}</li>
                  ))}
                </ul>
              </div>

              <div className="item">
                <div className="role">Skills snapshot</div>
                <ul>
                  <li>
                    <b>Languages:</b> {d.skills.languages.join(", ")}
                  </li>
                  <li>
                    <b>Data science & AI:</b> {d.skills.dataScience.join(", ")}
                  </li>
                  <li>
                    <b>Big data:</b> {d.skills.bigData.join(", ")}
                  </li>
                  <li>
                    <b>Omics:</b> {d.skills.omics.join(", ")}
                  </li>
                  <li>
                    <b>Structure:</b> {d.skills.structure.join(", ")}
                  </li>
                </ul>
              </div>
            </div>
          </Section>

          <footer className="footer">© {new Date().getFullYear()} Arghavan (Aria) Alisoltani</footer>
        </main>
      </div>
    </div>
  );
}
