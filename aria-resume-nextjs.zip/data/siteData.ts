export const siteData = {
  name: "Arghavan (Aria) Alisoltani, PhD",
  headline: "Computational Biology × Multi-Omics × Structural Bioinformatics",
  contact: {
    location: "Stillwater, OK • open to relocation/remote",
    phone: "951-455-1355",
    email: "arghavana85@gmail.com",
    website: "bioin.org",
    githubHandle: "ArghavanAlisoltani",
    linkedin: "", // add your URL if desired
    orcid: "",    // add your URL if desired
    scholar: ""   // add your URL if desired
  },
  highlights: [
    "U.S. PR (Green Card holder)",
    "9+ years postdoctoral experience",
    "h-index: 19 • citations: 3000+",
    "Successful CDC contract proposal (2023)",
    "Nextflow • HPC • AWS S3 • gcloud",
    "Python • R • Linux/Unix • Git • Shiny"
  ],
  callouts: [
    {
      tone: "blue",
      emoji: "🎯",
      text:
        "I build ML-enabled bioinformatics tools and scalable pipelines to interpret genomic variation and multi-omics data through a mechanistic lens—linking sequence variation to protein structure, function, and phenotype."
    },
    {
      tone: "orange",
      emoji: "🧬",
      text:
        "Core focus: variant interpretation, GWAS/marker discovery, metagenomics/metaproteomics, and structure-guided host–microbe interaction—delivered as reproducible workflows and interactive web tools (ViralVar, MetaProt, Coronavirus3D, FGTDB)."
    }
  ],
  experience: [
    {
      role: "Senior Researcher & Bioinformatician",
      org: "Oklahoma State University & University of Alberta",
      where: "USA / Canada (joint)",
      when: "2025 – present",
      bullets: [
        "Studying complex, giga-scale eukaryotic genomes and GWAS analysis.",
        "Mentoring junior scientists; providing technical direction on pipeline design."
      ]
    },
    {
      role: "Senior Researcher & Bioinformatician",
      org: "Northwestern University",
      where: "USA",
      when: "2022 – 2025",
      bullets: [
        "Developed ML-enabled webtool and pipelines for rapid analysis of viral genomic variants (ViralVar).",
        "GWAS to identify markers associated with virulence, cytotoxicity, and antimicrobial resistance."
      ]
    },
    {
      role: "Postdoctoral Research Associate",
      org: "University of California, Riverside",
      where: "USA",
      when: "2019 – 2022",
      bullets: [
        "Studied microbial evolution in the context of protein 3D structure and function.",
        "Chronic diseases multi-omics analysis and smoking effect on cancer immune microenvironment."
      ]
    },
    {
      role: "Postdoctoral Research Associate",
      org: "University of Cape Town",
      where: "South Africa",
      when: "2018 – 2019",
      bullets: [
        "Large-scale metaproteomics analysis to link microbial function and genital inflammation.",
        "Provided technical guidance and mentorship to junior scientists."
      ]
    },
    {
      role: "Postdoctoral Research Associate",
      org: "Vaal University of Technology",
      where: "South Africa",
      when: "2017 – 2018",
      bullets: [
        "Metagenomics studies to identify human disease-associated taxa."
      ]
    },
    {
      role: "Adjunct Lecturer",
      org: "Shahrekord University",
      where: "Iran",
      when: "2012 – 2014",
      bullets: ["Teaching and academic supervision responsibilities."]
    }
  ],
  grantsAwardsMentorship: {
    grant: {
      title: "CDC contract, BAA 75D301-23-R-72545 (SP0081422)",
      when: "2023 (1 year)",
      bullets: [
        "ML-based analysis and multilevel visualization webserver to study viral protein mutations."
      ]
    },
    awards: [
      "Fellowship award & ranked 3rd in National Universities entrance for master’s programs in science (2007).",
      "International Claude Leon Foundation Postdoctoral Fellowship (2018)."
    ],
    mentorship: [
      "Tayebeh Rahimi, MSc, Shahrekord University (2016–2018)",
      "Andrea Abraham, MSc, University of Cape Town (2018–2020)",
      "Shima Karami, PhD, Shahrekord University (2018–2023)",
      "Bahiah Meyer, PhD, University of Cape Town (2018–2025)"
    ]
  },
  education: [
    {
      degree: "PhD, Molecular Genetics — Bioinformatics",
      org: "Shahrekord University",
      when: "2011 – 2015"
    }
  ],
  pubs: {
    hIndex: 19,
    i10: 25,
    citations: "3000+"
  },
  skills: {
    languages: ["Python", "R", "Linux/Unix", "Shell scripting", "Git", "Shiny (dynamic UI)"],
    dataScience: ["SVM", "Random Forest", "Regression", "MLP", "Reinforcement learning", "Statistical analysis"],
    bigData: ["Nextflow", "HPC", "Cloud computing", "gcloud", "AWS S3"],
    omics: ["WGS/variant analysis", "GWAS", "Pan-genome", "RNA-seq/small RNA-seq", "LC-MS/MS", "Metagenomics/Metaproteomics", "WGCNA", "Cytoscape", "scRNA-seq"],
    structure: ["PyMOL", "AlphaFold"]
  },
  teachingIdeas: [
    "Bioinformatics pipelines (Nextflow, HPC, reproducibility)",
    "Genomics & variant interpretation (WGS, GWAS, AMR)",
    "ML for omics (baselines → DL → interpretation)"
  ],
  ai4bioIdeas: [
    "Short tutorials (GWAS, variant annotation, metaproteomics)",
    "Hands-on ML notes (modeling + evaluation + interpretability)",
    "Reusable pipelines and templates"
  ],
  assets: {
    avatar: "/avatar-placeholder.svg",
    resumePdf: "/Aria_Alisoltani_CV.pdf"
  }
};
