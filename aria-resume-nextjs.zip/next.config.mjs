/** @type {import('next').NextConfig} */
const nextConfig = {
  // If you want a static site (GitHub Pages), uncomment the next line:
  // output: "export",
  images: { unoptimized: true }
};

export default nextConfig;
